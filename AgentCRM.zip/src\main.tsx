/**
 * Punto de entrada de la aplicación
 */

import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './styles/index.css'

const rootElement = document.getElementById('root')

if (!rootElement) {
  throw new Error('No se encontró el elemento root')
}

createRoot(rootElement).render(
  <StrictMode>
    <App />
  </StrictMode>
)


